import 'package:flutter/material.dart';

class QuoteHistoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Örnek tarih ve duygu listesi (bu kısmı verilerinize göre düzenleyebilirsiniz)
    List<String> dates = ['2022-03-01', '2022-03-02', '2022-03-03'];
    List<String> emotions = ['Happy', 'Sad', 'Excited'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Quote History'),
      ),
      body: ListView.builder(
        itemCount: dates.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Tarih
                Container(
                  padding: EdgeInsets.all(5.0),
                  color: Colors.blue, // Tarih kutusunun rengi (istediğiniz renge değiştirebilirsiniz)
                  child: Text(
                    'Date: ${dates[index]}',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                // Duygu
                Container(
                  padding: EdgeInsets.all(5.0),
                  color: Colors.green, // Duygu kutusunun rengi (istediğiniz renge değiştirebilirsiniz)
                  child: Text(
                    'Emotion: ${emotions[index]}',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
