import 'package:flutter/material.dart';

import 'DetayliCiktiRaporu.dart';
import 'Logo.dart';

class DetayCiktiRaporu extends StatefulWidget {
  const DetayCiktiRaporu({Key? key}) : super(key: key);

  @override
  _DetayCiktiRaporuState createState() => _DetayCiktiRaporuState();
}

class _DetayCiktiRaporuState extends State<DetayCiktiRaporu> {
  Map<String, bool> checkboxValues = {
    'Günlük': false,
    'Haftalık': false,
    'Aylık': false,
    'Yıllık': false,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Spacer(),
            IconButton(
              icon: Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.calendar_today, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.notifications, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              onTap: () {
                _showOptionsDialog(context);
              },
              child: Container(
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Birim Seçiniz',
                      style: TextStyle(fontSize: 16, color: Colors.black),
                    ),
                    Icon(Icons.arrow_drop_down, color: Colors.black),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),
            _buildFormField('Personel Seçiniz'),
            SizedBox(height: 16),
            Text(
              'Tarih aralığı seçiniz',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _buildDateField('Başlangıç tarihi'),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: _buildDateField('Bitiş tarihi'),
                ),
              ],
            ),
            SizedBox(height: 24),
            Text(
              'Zaman sıklığı',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: checkboxValues.keys.map((String key) {
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Checkbox(
                      value: checkboxValues[key],
                      activeColor: Colors.blue,
                      onChanged: (bool? value) {
                        setState(() {
                          checkboxValues[key] = value ?? false;
                        });
                      },
                    ),
                    Text(key),
                  ],
                );
              }).toList(),
            ),
            SizedBox(height: 60),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ElevatedButton(
                onPressed: () {
                  _showConfirmationDialog(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF1F74EC),
                  minimumSize: Size(double.infinity, 42),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(21),
                  ),
                ),
                child: Text(
                  'İndir',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: buildBottomNavigationBar(context),
      floatingActionButton: _buildFloatingCenterButton(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,);
  }

  Widget buildBottomNavigationBar(BuildContext context) {
    return Container(
      height: 60,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Color(0xFF4E1BD9),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(35),
          topRight: Radius.circular(35),
          bottomLeft: Radius.circular(35),
          bottomRight: Radius.circular(35),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 60.0),
            child: IconButton(
              icon: Icon(Icons.home, size: 29, color: Colors.white),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 60.0),
            child: IconButton(
              icon: Icon(Icons.person, size: 29, color: Colors.white),
              onPressed: () {
                // Profil sayfasına yönlendirme
              },
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildFloatingCenterButton(BuildContext context) {
    return GestureDetector(
      onTap: () {

      },
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5,
          ),
        ),
        child: Center(
          child: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
        ),
      ),
    );
  }}


void _showOptionsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildOptionItem(context, 'Resepsiyon'),
                _buildOptionItem(context, 'Mutfak'),
                _buildOptionItem(context, 'Temizlik'),
                _buildOptionItem(context, 'Elektrik'),
                _buildOptionItem(context, 'Komi'),
                _buildOptionItem(context, 'Teknik'),
                _buildOptionItem(context, 'Lorem Ipsum'),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.check,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Tebrikler',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 8),
                Text(
                  'PDF Dosyası indirildi',
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1F74EC),
                  ),
                  child: Text(
                    'Tamam',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildOptionItem(BuildContext context, String option) {
    return ListTile(
      title: Text(option),
      onTap: () {
        Navigator.pop(context);
      },
    );
  }

  Widget _buildFormField(String label) {
    return TextField(
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }

  Widget _buildDateField(String label) {
    return TextField(
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }

