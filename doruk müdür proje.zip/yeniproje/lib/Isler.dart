import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'DetayliCiktiRaporu.dart';
import 'IsAtamasi.dart';
import 'Logo.dart';
import 'TamamlananIsler.dart';

class Isler extends StatefulWidget {
  const Isler({Key? key}) : super(key: key);

  @override
  _IslerState createState() => _IslerState();
}

class _IslerState extends State<Isler> {
  int selectedIndex = 0;

  Future<List<Map<String, dynamic>>> fetchTasks(String status) async {
    String url;
    if (status == 'completed') {
      url = 'https://s3uploader.fly.dev/tasks/completed';
    } else if (status == 'pending') {
      url = 'https://s3uploader.fly.dev/tasks/pending';
    } else if (status == 'inprogress') {
      url = 'https://s3uploader.fly.dev/tasks/inprogress';
    } else {
      url = 'https://s3uploader.fly.dev/tasks';
    }

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return List<Map<String, dynamic>>.from(data['tasks']);
    } else {
      throw Exception('Failed to load tasks');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Spacer(),
            IconButton(
              icon: Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.calendar_today, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.notifications, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildTabButton('Atanan', 0),
                SizedBox(width: 20),
                _buildTabButton('Tamamlanan', 1),
                SizedBox(width: 20),
                _buildTabButton('Tamamlanmadı', 2),
              ],
            ),
            SizedBox(height: 10),
            SizedBox(height: 10),
            Expanded(
              child: _buildTabContent(),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        height: 60,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xFF4E1BD9),
          borderRadius: BorderRadius.circular(35),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 60.0),
              child: IconButton(
                icon: Icon(Icons.home, size: 29, color: Colors.white),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 60.0),
              child: IconButton(
                icon: Icon(Icons.person, size: 29, color: Colors.white),
                onPressed: () {
                  // Profil sayfasına yönlendirme
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5,
          ),
        ),
        child: IconButton(
          icon: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => DetayliCiktiRaporu()),
            );
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Future<void> _refreshCompletedTasks() async {
    List<Map<String, dynamic>> tasks = await fetchTasks('completed');
    setState(() {
      // Bu state güncellemesi ile tamamlanan görevler listesi yenilenir.
    });
  }



  Widget _buildTabButton(String title, int index) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedIndex = index;
          });
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 8.0),
          decoration: BoxDecoration(
            color: selectedIndex == index ? Colors.blue : Colors.grey.shade300,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Center(
            child: Text(
              title,
              style: TextStyle(
                fontFamily: 'LibreFranklin-Medium',
                fontSize: 14,
                color: selectedIndex == index ? Colors.white : Colors.black,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusContainer(int taskCount) {
    Color backgroundColor;
    String labelText;

    switch (selectedIndex) {
      case 0:
        backgroundColor = Color(0xFFDDFCE0);
        labelText = 'Atanan';
        break;
      case 1:
        backgroundColor = Color(0xFFF3EEFE);
        labelText = 'Tamamlanan';
        break;
      case 2:
        backgroundColor = Color(0xFFFEF0DB);
        labelText = 'Tamamlanmadı';
        break;
      default:
        backgroundColor = Colors.white;
        labelText = '';
    }

    return Container(
      width: double.infinity,
      height: 60,
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween, // Sol ve sağa hizalama
        children: [
          Text(
            labelText,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 14.0), // Sağdan biraz boşluk ekleyin
            child: Text(
              taskCount.toString(), // Sadece sayı sağda olacak
              style: TextStyle(
                fontSize: 23, // Font size 23
                fontWeight: FontWeight.w600, // Semi-bold
                fontFamily: 'LibreFranklin-SemiBold',
              ),
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildTabContent() {
    String status;
    switch (selectedIndex) {
      case 0:
        status = 'inprogress';
        break;
      case 1:
        status = 'completed';
        break;
      case 2:
        status = 'pending';
        break;
      default:
        status = '';
    }

    return FutureBuilder<List<Map<String, dynamic>>>(
      future: fetchTasks(status),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Veri yüklenemedi: ${snapshot.error}'));
        } else {
          List<Map<String, dynamic>> tasks = snapshot.data ?? [];
          int taskCount = tasks.length; // Kişi sayısını burada hesaplayın
          return Column(
            children: [
              // Kişi sayısını `_buildStatusContainer`'a iletin
              _buildStatusContainer(taskCount),
              SizedBox(height: 16),
              Expanded(
                child: tasks.isEmpty
                    ? Center(child: Text('Görev bulunamadı.'))
                    : ListView.builder(
                  itemCount: selectedIndex == 0 ? tasks.length + 1 : tasks.length,
                  itemBuilder: (context, index) {
                    if (selectedIndex == 0 && index == tasks.length) {
                      // 'Atanan İş' sekmesinde '+ Ekle' butonunu ekle
                      return Padding(
                        padding: const EdgeInsets.only(top: 8.0, bottom: 40.0),
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => IsAtamasi()),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xFF1F74EC),
                            minimumSize: Size(double.infinity, 42),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(21),
                            ),
                          ),
                          child: Text(
                            '+ Ekle',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                      );
                    }

                    final task = tasks[index];
                    return _buildTaskCard(
                      task['assignee'] ?? 'Bilinmiyor',
                      task['department'] ?? 'Bilinmiyor',
                      task['title'] ?? 'Görev Başlığı Yok',
                      task['status'] ?? 'Durum Yok',
                      task['created_at'] ?? 'Zaman Bilinmiyor',
                      task['start_time'] ?? 'Zaman Bilinmiyor',
                      task['complete_time'] ?? 'Zaman Bilinmiyor',
                      Colors.grey.shade200,
                      index, // Kart sırasını iletin
                    );
                  },
                )
              ),
            ],
          );
        }
      },
    );
  }


  Widget _buildTaskCard(
      String name,
      String role,
      String task,
      String status,
      String createdAt,
      String startTime,
      String completeTime,
      Color backgroundColor,
      int index, // Kartın sırasını belirtmek için indeks ekliyoruz
      ) {
    // İndekse bağlı olarak arka plan rengini belirler
    Color departmentColor = (index % 2 == 0) ? Color(0xFFDDCBFC) : Color(0xFFADCFFF);

    return GestureDetector(
      onTap: () {
        if (selectedIndex == 1) { // Tamamlanan sekmesindeyken
          if (task is String) {
            // task bir String ise, basit bir Map oluşturun
            final taskDetails = {
              'title': task,
              // Burada ihtiyacınıza göre ek alanlar ekleyebilirsiniz
            };

            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => TamamlananIsler(taskDetails: taskDetails, photos: [],),
              ),
            ).then((value) {
              if (value == true) {
                _refreshCompletedTasks(); // Yenileme fonksiyonunu çağır
              }
            });
          } else {
            print('Geçersiz veri formatı: ${task.runtimeType}');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Geçersiz veri formatı: ${task.runtimeType}')),
            );
          }
        }
      },
      child: Card(
    margin: EdgeInsets.only(bottom: 16.0),
    child: Padding(
    padding: const EdgeInsets.all(16.0),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: Colors.grey.shade300,
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          width: 116,
                          height: 30,
                          decoration: BoxDecoration(
                            color: departmentColor, // Belirttiğiniz arka plan rengi
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Center(
                            child: Text(
                              role,
                              style: TextStyle(
                                fontSize: 12,
                                fontFamily: 'LibreFranklin-Medium',
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Üç nokta yerine fotoğraf simgesi sadece 'Tamamlanan' sekmesi için
                selectedIndex == 1
                    ? IconButton(
                  icon: Icon(Icons.photo_camera, color: Colors.black),
                  onPressed: () {
                    // Fotoğraf işlemi için gereken kod
                  },
                )
                    : PopupMenuButton<int>(
                  icon: Icon(Icons.more_horiz, color: Colors.black),
                  onSelected: (int result) {
                    if (result == 0) {
                      print("Düzenle seçildi");
                    } else if (result == 1) {
                      print("Sil seçildi");
                    }
                  },
                  itemBuilder: (BuildContext context) =>
                  <PopupMenuEntry<int>>[
                    PopupMenuItem<int>(
                      value: 0,
                      child: ListTile(
                        leading: Icon(Icons.edit, color: Colors.black, size: 25),
                        title: Text('Düzenle', style: TextStyle(fontSize: 14)),
                      ),
                    ),
                    PopupMenuItem<int>(
                      value: 1,
                      child: ListTile(
                        leading: Icon(Icons.delete, color: Colors.red, size: 25),
                        title: Text('Sil', style: TextStyle(fontSize: 14)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              'GÖREV: $task',
              style: TextStyle(
                fontSize: 12,
                fontFamily: 'LibreFranklin-Medium',
              ),
            ),
            SizedBox(height: 8),
            _buildInfoRow('Oluşturulma Tarihi:', createdAt),
            _buildInfoRow('Başlama Zamanı:', startTime),
            _buildInfoRow('Tamamlanma Zamanı:', completeTime),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Durum',
                  style: TextStyle(
                    fontSize: 12,
                    fontFamily: 'Mulish-SemiBold',
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: status == 'completed' ? Color(0xFF50C006) : Color(0xFFC00606),
                    ),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  child: Text(
                    status,
                    style: TextStyle(
                      color: status == 'completed'
                          ? Color(0xFF50C006)
                          : Color(0xFFC00606),
                      fontSize: 12,
                      fontFamily: 'Mulish-SemiBold', // Font ailesi
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),);
  }



  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontFamily: 'LibreFranklin-Medium',
          ),
        ),
        Flexible(
          child: Text(
            value,
            style: TextStyle(
              fontSize: 12,
              fontFamily: 'LibreFranklin-Medium',
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
