import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'DetayliCiktiRaporu.dart';
import 'Logo.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;


class TamamlananIsler extends StatelessWidget {
  final Map<String, dynamic> taskDetails;
  final List<File> photos; // Fotoğraflar için ekledik
  Future<List<File>> loadSavedImages() async {
    List<String> imagePaths = await loadImagePaths();
    return imagePaths.map((path) => File(path)).toList();
  }

  Future<Map<String, dynamic>> fetchTaskDetails(int taskId) async {
    final response = await http.get(Uri.parse('https://s3uploader.fly.dev/tasks/$taskId'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data; // API'nin yanıt formatına bağlı olarak bu kısmı uyarlayın
    } else {
      throw Exception('Görev detayları yüklenemedi');
    }
  }

  Future<void> saveImagePaths(List<String> imagePaths) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('savedImagePaths', imagePaths);
  }

  Future<List<String>> loadImagePaths() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('savedImagePaths') ?? [];
  }



  TamamlananIsler({required this.taskDetails, required this.photos});
  Future<String> saveImage(File image) async {
    final directory = await getApplicationDocumentsDirectory();
    final imagePath = '${directory.path}/${DateTime.now().millisecondsSinceEpoch}.png';
    final savedImage = await image.copy(imagePath);
    return savedImage.path;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.search, color: Colors.black),
                  onPressed: () {},
                ),
                IconButton(
                  icon: Icon(Icons.notifications, color: Colors.black),
                  onPressed: () {},
                ),
              ],
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                taskDetails['title'] ?? 'Başlık Yok',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              Card(
                margin: EdgeInsets.symmetric(vertical: 16),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Gönderilme Zamanı: ${taskDetails['created_at'] ?? 'Bilinmiyor'}',
                              style: TextStyle(fontSize: 16),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Divider(
                        color: Colors.grey.shade400,
                        thickness: 1.0,
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Atayan Kişi: ${taskDetails['assignee'] ?? 'İsim Soyisim - Ünvan'}',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 8),
                      Divider(
                        color: Colors.grey.shade400,
                        thickness: 1.0,
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Teslim Tarihi: ${taskDetails['due_date'] ?? 'Bilinmiyor'}',
                        style: TextStyle(fontSize: 16, color: Colors.red),
                      ),
                      SizedBox(height: 8),
                      Divider(
                        color: Colors.grey.shade400,
                        thickness: 1.0,
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Detay Bilgi:\n${taskDetails['details'] ?? 'Detay bilgisi mevcut değil'}',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 8),
                      Divider(
                        color: Colors.grey.shade400,
                        thickness: 1.0,
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Açıklama:\n${taskDetails['description'] ?? 'Açıklama mevcut değil'}',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 8),
                      Divider(
                        color: Colors.grey.shade400,
                        thickness: 1.0,
                      ),
                      SizedBox(height: 16),
                      // Eklenen yeni alanlar için örnek
                      if (taskDetails.containsKey('priority'))
                        Text(
                          'Öncelik: ${taskDetails['priority'] ?? 'Bilgi mevcut değil'}',
                          style: TextStyle(fontSize: 16),
                        ),
                      if (taskDetails.containsKey('status'))
                        Text(
                          'Durum: ${taskDetails['status'] ?? 'Bilgi mevcut değil'}',
                          style: TextStyle(fontSize: 16),
                        ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              // Fotoğrafların gösterimi
              if (photos.isNotEmpty)
                Container(
                  height: 200,
                  child: PageView.builder(
                    itemCount: photos.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return Dialog(
                                child: Container(
                                  color: Colors.black,
                                  child: Stack(
                                    children: [
                                      Center(
                                        child: Image.file(photos[index]),
                                      ),
                                      Positioned(
                                        top: 20,
                                        right: 20,
                                        child: IconButton(
                                          icon: Icon(Icons.close, color: Colors.white),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );
                        },
                        child: Image.file(
                          photos[index],
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  ),
                ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  GestureDetector(
                    onTap: () {
                      // Fotoğraf ekleme işlemi
                    },
                    child: Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                      ),
                      child: Icon(Icons.image, color: Colors.grey),
                    ),
                  ),
                  Spacer(),
                  GestureDetector(
                    onTap: () {
                      // Uyarı verme işlemi
                    },
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/images/uyari.png',
                          height: 60,
                          width: 60,
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Uyarı Ver',
                          style: TextStyle(fontSize: 18),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 14),
              ElevatedButton(
                onPressed: () {
                  // Onay işlemi
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF1F74EC),
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text(
                  'Onayla',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 60,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xFF4E1BD9),
          borderRadius: BorderRadius.circular(35),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 60.0),
              child: IconButton(
                icon: Icon(Icons.home, size: 29, color: Colors.white),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 60.0),
              child: IconButton(
                icon: Icon(Icons.person, size: 29, color: Colors.white),
                onPressed: () {
                  // Profil sayfasına yönlendirme
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5,
          ),
        ),
        child: IconButton(
          icon: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => DetayliCiktiRaporu()),
            );
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
