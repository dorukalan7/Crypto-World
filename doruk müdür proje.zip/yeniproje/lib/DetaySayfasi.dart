import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import 'TamamlananIsler.dart';

class DetaySayfasi extends StatefulWidget {
  final int taskId; // Görev ID'sini geçmek için
  final Map<String, dynamic> taskDetails;

  DetaySayfasi({required this.taskId, required this.taskDetails, required Map odaBilgisi});

  @override
  _DetaySayfasiState createState() => _DetaySayfasiState();
}

class _DetaySayfasiState extends State<DetaySayfasi> {
  bool isStarted = false;
  Timer? timer;
  int secondsPassed = 0;
  DateTime? startTime;
  final ImagePicker _picker = ImagePicker();
  List<File> _imageFiles = [];
  Map<String, dynamic> taskDetails = {};

  Future<String> saveImage(File image) async {
    final directory = await getApplicationDocumentsDirectory();
    final imagePath = '${directory.path}/${DateTime.now().millisecondsSinceEpoch}.png';
    final savedImage = await image.copy(imagePath);
    return savedImage.path;
  }

  Future<void> saveImagePaths(List<String> imagePaths) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('savedImagePaths', imagePaths);
  }

  Future<List<String>> loadImagePaths() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('savedImagePaths') ?? [];
  }



  @override
  void initState() {
    super.initState();
    if (widget.taskDetails.isNotEmpty) {
      setState(() {
        taskDetails = widget.taskDetails; // Gelen bilgileri başlangıçta yükleyin
      });
    }
    _fetchTaskDetails(); // Ekstra bilgi çekmek isterseniz
  }


  Future<void> _fetchTaskDetails() async {
    try {
      final response = await http.get(Uri.parse('https://s3uploader.fly.dev/tasks/${widget.taskId}'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        print('API Yanıtı: $data'); // Yanıtın içeriğini kontrol edin
        setState(() {
          taskDetails = data;
        });
      } else {
        print('Görev detayları yüklenemedi: ${response.statusCode}');
      }
    } catch (e) {
      print('Görev detayları çekilirken hata: $e');
    }
  }



  Future<void> _loadTimerState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int savedSeconds = prefs.getInt('secondsPassed_${widget.taskId}') ?? 0;
    bool wasRunning = prefs.getBool('isStarted_${widget.taskId}') ?? false;
    String? savedStartTime = prefs.getString('startTime_${widget.taskId}');

    setState(() {
      secondsPassed = savedSeconds;
      isStarted = wasRunning;
      if (savedStartTime != null) {
        startTime = DateTime.parse(savedStartTime);
      }
    });

    if (wasRunning && startTime != null) {
      int elapsed = DateTime.now().difference(startTime!).inSeconds;
      setState(() {
        secondsPassed += elapsed;
      });
      _resumeTimer();
    }
  }

  Future<void> _takePhoto() async {
    if (_imageFiles.length < 2) {
      final XFile? photo = await _picker.pickImage(source: ImageSource.camera);
      if (photo != null) {
        setState(() {
          _imageFiles.add(File(photo.path));
        });
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Maksimum iki fotoğraf eklenebilir.')),
      );
    }
  }

  Future<void> _pickFromGallery() async {
    if (_imageFiles.length < 2) {
      final XFile? photo = await _picker.pickImage(source: ImageSource.gallery);
      if (photo != null) {
        setState(() {
          _imageFiles.add(File(photo.path));
        });
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Maksimum iki fotoğraf eklenebilir.')),
      );
    }
  }

  Future<void> _saveTimerState() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('secondsPassed_${widget.taskId}', secondsPassed);
    await prefs.setBool('isStarted_${widget.taskId}', isStarted);
    if (isStarted && startTime != null) {
      await prefs.setString('startTime_${widget.taskId}', startTime!.toIso8601String());
    }
  }

  void _startTask() {
    setState(() {
      isStarted = true;
      startTime = DateTime.now();
      secondsPassed = 0;
    });
    _saveTimerState();
    _startTimer();
  }

  void _resumeTimer() {
    _startTimer();
  }

  void _startTimer() {
    timer = Timer.periodic(Duration(seconds: 1), (Timer t) {
      setState(() {
        secondsPassed++;
      });
      _saveTimerState();
    });
  }

  void _stopTask() {
    timer?.cancel();
    setState(() {
      isStarted = false;
    });
    _saveTimerState();
  }

  String _formatTime(int seconds) {
    int minutes = seconds ~/ 60;
    int remainingSeconds = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  void _showTamamlandiDialog() {
    _stopTask();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.check_circle, color: Colors.green, size: 80),
              SizedBox(height: 16),
              Text(
                'Tebrikler',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'İş Başarı ile Tamamlandı',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('Tamam'),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showWarningDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            'Neden Uyarı Vermek İstiyorsunuz?',
            style: TextStyle(color: Colors.red),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text('Eksik Parça'),
                leading: Radio<String>(
                  value: 'Eksik Parça',
                  groupValue: selectedWarning,
                  onChanged: (value) {
                    setState(() {
                      selectedWarning = value;
                    });
                    Navigator.pop(context);
                  },
                ),
              ),
              ListTile(
                title: Text('Tamir Edilemez'),
                leading: Radio<String>(
                  value: 'Tamir Edilemez',
                  groupValue: selectedWarning,
                  onChanged: (value) {
                    setState(() {
                      selectedWarning = value;
                    });
                    Navigator.pop(context);
                  },
                ),
              ),
              ListTile(
                title: Text('Lorem Ipsum 1'),
                leading: Radio<String>(
                  value: 'Lorem Ipsum 1',
                  groupValue: selectedWarning,
                  onChanged: (value) {
                    setState(() {
                      selectedWarning = value;
                    });
                    Navigator.pop(context);
                  },
                ),
              ),
              ListTile(
                title: Text('Lorem Ipsum 2'),
                leading: Radio<String>(
                  value: 'Lorem Ipsum 2',
                  groupValue: selectedWarning,
                  onChanged: (value) {
                    setState(() {
                      selectedWarning = value;
                    });
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
          actions: [
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('Onayla'),
              ),
            ),
          ],
        );
      },
    );
  }

  String? selectedWarning;

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Widget buildBottomNavigationBar(BuildContext context) {
    return Container(
      height: 60,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Color(0xFF4E1BD9),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(35),
          topRight: Radius.circular(35),
          bottomLeft: Radius.circular(35),
          bottomRight: Radius.circular(35),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 60.0),
            child: IconButton(
              icon: Icon(Icons.home, size: 29, color: Colors.white),
              onPressed: () {},
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 60.0),
            child: IconButton(
              icon: Icon(Icons.person, size: 29, color: Colors.white),
              onPressed: () {
                // Profil sayfasına yönlendirme
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingCenterButton(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5,
          ),
        ),
        child: Center(
          child: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
        ),
      ),
    );
  }
  Future<void> _markTaskAsCompleted(int taskId) async {
    try {
      final response = await http.put(
        Uri.parse('https://s3uploader.fly.dev/tasks/$taskId/complete'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        print('Görev başarıyla tamamlandı: ${json.decode(response.body)['message']}');
        // İsteğin başarılı olduğu durumda kullanıcıya bildirim gösterilebilir.
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Görev başarıyla tamamlandı')),
        );
      } else {
        print('Görev güncellenemedi: ${response.statusCode}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Görev güncellenemedi')),
        );
      }
    } catch (e) {
      print('Görev tamamlanırken hata: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Bir hata oluştu: $e')),
      );
    }
  }

  Future<void> _refreshCompletedTasks() async {
    // Tamamlanan görevlerin yenilenmesi için gereken işlemleri buraya ekleyin.
    // Örneğin, görevlerin API'den yeniden çekilmesi veya listenin güncellenmesi gibi işlemler olabilir.
    print('Tamamlanan görevler yenilendi.');
    // Bu fonksiyonu, verileri yeniden yükleyecek şekilde genişletebilirsiniz.
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.search, color: Colors.black),
                  onPressed: () {},
                ),
                IconButton(
                  icon: Icon(Icons.notifications, color: Colors.black),
                  onPressed: () {},
                ),
              ],
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              taskDetails['title'] ?? 'Görev Başlığı Yok',
              style: TextStyle(
                fontSize: 24,
                fontFamily: 'LibreFranklin-SemiBold',
                color: Color(0xFF23272C),
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                if (isStarted)
                  Text(
                    _formatTime(secondsPassed),
                    style: TextStyle(fontSize: 18, color: Colors.black),
                  ),
                Spacer(),
                ElevatedButton(
                  onPressed: isStarted ? null : _startTask,
                  child: Text(isStarted ? 'Devam Ediyor' : 'Başla'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isStarted ? Colors.blue : Colors.grey,
                  ),
                ),
              ],
            ),
            Card(
              margin: EdgeInsets.symmetric(vertical: 16),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Gönderilme Zamanı: ${taskDetails['created_at'] ?? 'Bilinmiyor'}',
                      style: TextStyle(fontSize: 16),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Atanan Kişi: ${taskDetails['assignee'] ?? 'İsim Soyisim - Ünvan'}',
                      style: TextStyle(fontSize: 16),
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Teslim Tarihi: ${taskDetails['due_date'] ?? 'Bilinmiyor'}',
                            style: TextStyle(fontSize: 16, color: Colors.red),
                          ),
                        ),
                        // Fotoğraf çekme ve galeri seçme ikonları
                        GestureDetector(
                          onTap: _takePhoto,
                          child: Icon(Icons.camera_alt, size: 30, color: Colors.grey),
                        ),
                        SizedBox(width: 16),
                        GestureDetector(
                          onTap: _pickFromGallery,
                          child: Icon(Icons.photo, size: 30, color: Colors.grey),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Detay Bilgi:\n${taskDetails['details'] ?? 'Detay bilgisi mevcut değil'}',
                      style: TextStyle(fontSize: 16),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Açıklama:\n${taskDetails['description'] ?? 'Açıklama mevcut değil'}',
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                for (int i = 0; i < 2; i++)
                  Container(
                    width: 50,
                    height: 50,
                    margin: EdgeInsets.only(right: 16),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                    ),
                    child: _imageFiles.length > i
                        ? Image.file(_imageFiles[i], fit: BoxFit.cover)
                        : Icon(Icons.image, color: Colors.grey),
                  ),
                Spacer(),
                Column(
                  children: [
                    GestureDetector(
                      onTap: _showWarningDialog,
                      child: Image.asset(
                        'assets/images/uyari.png',
                        height: 50,
                        width: 50,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text('Uyarı Ver'),
                  ],
                ),
              ],
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: (isStarted && _imageFiles.isNotEmpty) ? () async {
                await _markTaskAsCompleted(widget.taskId);
                // İşlem tamamlandıktan sonra tamamlanan işler sayfasına yönlendir
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TamamlananIsler(
                      taskDetails: taskDetails,
                      photos: _imageFiles, // Fotoğrafları gönderiyoruz
                    ),
                  ),
                ).then((value) {
                  _refreshCompletedTasks(); // Tamamlanan görevleri yenile
                });
              } : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: (isStarted && _imageFiles.isNotEmpty) ? Colors.green : Colors.grey,
                minimumSize: Size(double.infinity, 50),
              ),
              child: Text(
                'Tamamlandı',
                style: TextStyle(fontSize: 18),
              ),
            ),


          ],
        ),
      ),
      bottomNavigationBar: buildBottomNavigationBar(context),
      floatingActionButton: _buildFloatingCenterButton(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
