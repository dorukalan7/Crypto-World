import 'package:flutter/material.dart';
import 'package:yeniproje/CalisanlarPage.dart';

import 'DetayCiktiRaporu.dart';
import 'IsAtamasi.dart';
import 'Isler.dart';
import 'Logo.dart';
 // HomePage'in tanımlı olduğu dosyayı dahil edin

class DetayliCiktiRaporu extends StatelessWidget {
  const DetayliCiktiRaporu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context); // Geri tuşuna basıldığında önceki sayfaya dön
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Spacer(),
            IconButton(
              icon: Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.calendar_today, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.notifications, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildColoredCard(context, 'Genel Performans Raporları', Colors.green.shade100, Colors.green),
                _buildColoredCard(context, 'Çalışma Saatleri ve Devamsızlık Raporları', Colors.orange.shade100, Colors.orange),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildColoredCard(context, 'Verimlilik Analizleri', Colors.blue.shade100, Colors.blue),
                _buildColoredCard(context, 'Harcamalar', Colors.purple.shade100, Colors.purple),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildColoredCard(context, 'Çalışanlar', Colors.green.shade100, Colors.green),
                _buildColoredCard(context, 'İşler', Colors.orange.shade100, Colors.orange),
              ],
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildColoredCard(context, 'Resepsiyon', Colors.blue.shade100, Colors.blue),
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: buildBottomNavigationBar(context),
      floatingActionButton: _buildFloatingCenterButton(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget buildBottomNavigationBar(BuildContext context) {
    return Container(
      height: 60,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Color(0xFF4E1BD9),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(35),
          topRight: Radius.circular(35),
          bottomLeft: Radius.circular(35),
          bottomRight: Radius.circular(35),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 60.0),
            child: IconButton(
              icon: Icon(Icons.home, size: 29, color: Colors.white),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 60.0),
            child: IconButton(
              icon: Icon(Icons.person, size: 29, color: Colors.white),
              onPressed: () {
                // Profil sayfasına yönlendirme
              },
            ),
          ),
        ],
      ),
    );
  }


  Widget _buildFloatingCenterButton(BuildContext context) {
    return GestureDetector(
      onTap: () {

      },
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5,
          ),
        ),
        child: Center(
          child: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
        ),
      ),
    );
  }}


Widget _buildColoredCard(BuildContext context, String text, Color bgColor, Color borderColor) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          if (text == 'Genel Performans Raporları') {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => DetayCiktiRaporu()), // DetayCiktiRaporu sayfasına yönlendirme
            );
          } else if (text == 'İşler') {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Isler()), // İsler sayfasına yönlendirme
            );
          }else if (text == 'Çalışanlar') {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => CalisanlarPage()), // İsler sayfasına yönlendirme
            );
          }
        },
        child: Container(
          height: 100,
          margin: EdgeInsets.only(right: 8.0),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Row(
            children: [
              Container(
                width: 5,
                height: 60,
                margin: EdgeInsets.only(left: 10),
                color: borderColor,
              ),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  text,
                  style: TextStyle(fontSize: 16, color: Colors.black),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

