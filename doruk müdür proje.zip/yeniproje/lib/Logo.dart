import 'package:flutter/material.dart';
import 'CalisanlarPage.dart';
import 'DetayliCiktiRaporu.dart';
import 'Isler.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'firebase_options.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Arka planda gelen bildirimleri işler
  print('Handling a background message: ${message.messageId}');
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,);

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  // Tokeni almak ve konsola yazdırmak
  FirebaseMessaging.instance.getToken().then((String? token) {
    print("Cihaz Tokeni: $token");
    // Postman veya diğer testlerde kullanmak için bu tokeni kopyalayın
  });

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView( // SingleChildScrollView eklendi
        child: Column(
          children: [
            // Üst kısım (Mavi arka plan %20)
            Container(
              width: double.infinity,
              height: 932 * 0.2, // Ekranın %20'si mavi
              color: Color(0xFF1F74EC),
              padding: EdgeInsets.only(left: 30),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'LOGO',
                    style: TextStyle(color: Colors.white, fontSize: 22),
                    textAlign: TextAlign.left,
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Giriş Metni',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                    textAlign: TextAlign.left,
                  ),
                ],
              ),
            ),
            // Alt kısım (Beyaz arka plan %80)
            Container(
              width: double.infinity,
              color: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Giriş Yap',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 20),
                  // Kullanıcı adı alanı
                  Text(
                    'Kullanıcı Adı',
                    style: TextStyle(color: Colors.black, fontSize: 14),
                  ),
                  SizedBox(height: 5),
                  SizedBox(
                    height: 45,
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  // Şifre alanı
                  Text(
                    'Şifre',
                    style: TextStyle(color: Colors.black, fontSize: 14),
                  ),
                  SizedBox(height: 5),
                  SizedBox(
                    height: 45,
                    child: TextField(
                      obscureText: true,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Checkbox(
                        value: false,
                        onChanged: (value) {},
                      ),
                      Text('Beni Hatırla', style: TextStyle(fontSize: 14)),
                    ],
                  ),
                  SizedBox(height: 20),
                  // Giriş yap butonu
                  Center(
                    child: SizedBox(
                      width: double.infinity,
                      height: 45,
                      child: ElevatedButton(
                        onPressed: () {
                          // Giriş yapıldığında anasayfaya git
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => HomePage()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFF1F74EC),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        child: Text(
                          'Giriş Yap',
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}



class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Üst Kısım (Logo ve simgeler)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Logo',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.normal,
                      color: Colors.black,
                    ),
                  ),
                  Row(
                    children: [
                      Icon(Icons.search, size: 30, color: Colors.black),
                      SizedBox(width: 16),
                      Icon(Icons.notifications, size: 28, color: Colors.black),
                      SizedBox(width: 16),
                      Icon(Icons.calendar_today, size: 26, color: Colors.black),
                      SizedBox(width: 16),
                      CircleAvatar(
                        backgroundColor: Colors.grey.shade300,
                        radius: 20,
                        child: Icon(Icons.person, color: Colors.white),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 24),
              // Çalışanlar ve İşler Kısımları
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CalisanlarPage()),
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.42,
                      height: 120,
                      decoration: BoxDecoration(
                        color: Color(0xFFDDFAE0),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            left: 16,
                            top: 40,
                            child: Container(
                              width: 5,
                              height: 40,
                              color: Color(0xFF0EB01D),
                            ),
                          ),
                          Positioned(
                            left: 40,
                            top: 48,
                            child: Text(
                              'Çalışanlar',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF343942),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Isler()),
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.42,
                      height: 120,
                      decoration: BoxDecoration(
                        color: Color(0xFFFEF0DB),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            left: 16,
                            top: 40,
                            child: Container(
                              width: 5,
                              height: 40,
                              color: Color(0xFFFAAB3C),
                            ),
                          ),
                          Positioned(
                            left: 40,
                            top: 48,
                            child: Text(
                              'İşler',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF343942),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              // Resepsiyon Bölümü
              Container(
                width: double.infinity,
                height: 120,
                decoration: BoxDecoration(
                  color: Color(0xFFE4EAF7),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 16,
                      top: 40,
                      child: Container(
                        width: 5,
                        height: 40,
                        color: Color(0xFF72A7FF),
                      ),
                    ),
                    Positioned(
                      left: 40,
                      top: 48,
                      child: Text(
                        'Resepsiyon',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF343942),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24),
              // Harcamalar Bölümü
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xFFF3EEFE),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Harcamalar',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF23272C),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Color(0xFFF8D8AB),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Text(
                            'Ocak',
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF23272C),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    Center(
                      child: Stack(
                        alignment: Alignment.center, // Ortaya hizalar
                        children: [
                          Container(
                            width: 170, // Dairesel ilerleme göstergesinin genişliği
                            height: 170,
                            child: CircularProgressIndicator(
                              value: 0.95, // Yüzdeyi temsil eden değer (0.0 - 1.0 arasında)
                              strokeWidth: 12,
                              backgroundColor: Colors.grey.shade300,
                              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF8A56AC)),
                            ),
                          ),
                      Column(
                        mainAxisSize: MainAxisSize.min, // Sadece içeriğe göre boyutlanır
                        children: [
                          Text(
                            '95%', // Yüzde metni
                            style: TextStyle(
                              fontSize: 42, // Yazı boyutu
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF23272C),
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            'Toplam Harcama',
                            style: TextStyle(
                              fontSize: 14,
                              color: Color(0xFF23272C),
                            ),
                          ),
                        ],
                      ),
                        ],
                    ),),
                    SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Genel Harcama',
                          style: TextStyle(fontSize: 14, color: Color(0xFF5D6675)),
                        ),
                        Text(
                          '%70',
                          style: TextStyle(fontSize: 16, color: Color(0xFF23272C)),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Ekstra Harcama',
                          style: TextStyle(fontSize: 14, color: Color(0xFF23272C)),
                        ),
                        Text(
                          '%25',
                          style: TextStyle(fontSize: 16, color: Color(0xFF23272C)),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Toplam Harcama',
                          style: TextStyle(fontSize: 14, color: Color(0xFF23272C)),
                        ),
                        Text(
                          '%95',
                          style: TextStyle(fontSize: 16, color: Color(0xFF23272C)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 60,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xFF4E1BD9),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(35),
            topRight: Radius.circular(35),
            bottomLeft: Radius.circular(35),
            bottomRight: Radius.circular(35),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
                padding: const EdgeInsets.only(left: 60.0),
                child: IconButton(
                  icon: Icon(Icons.home, size: 29, color: Colors.white),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  },
                )),
            Padding(
              padding: const EdgeInsets.only(right: 60.0),
              child: IconButton(
                icon: Icon(Icons.person, size: 29, color: Colors.white),
                onPressed: () {
                  // Profil sayfasına yönlendirme
                },
              ),
            ),],

        ),
      ),
      floatingActionButton: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5, // Kenar boşluğu kalınlığı
          ),
        ),
        child: IconButton(
          icon: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => DetayliCiktiRaporu()),
            );
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}