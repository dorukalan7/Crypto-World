import 'dart:async';

import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class BitcoinScreen extends StatefulWidget {
  @override
  _BitcoinScreenState createState() => _BitcoinScreenState();
}

class _BitcoinScreenState extends State<BitcoinScreen> with SingleTickerProviderStateMixin {
  TabController? _tabController;
  Map<String, List<FlSpot>>? chartData;
  String selectedRange = '1h';
  double? lastPrice;
  double? highPrice;
  double? lowPrice;
  double? change;
  bool isLoading = false; // Yükleme durumunu izlemek için
  Timer? _timer; // Timer değişkeni
  final List<String> ranges = [
    '10m', '30m', '1h', '4h', '24h', '7d', '1m'
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: ranges.length, vsync: this);
    _fetchChartData();
    // 20 saniyede bir _fetchChartData() fonksiyonunu çağırmak için Timer oluşturuyoruz
    _timer = Timer.periodic(Duration(seconds: 10), (Timer t) {
      if (!isLoading) { // Yükleme sırasında tekrar çağırmaktan kaçının
        _fetchChartData();}});


    _tabController!.addListener(() {
      setState(() {
        selectedRange = ranges[_tabController!.index];
        _fetchChartData();
      });
    });
  }
  @override
  void dispose() {
    _timer?.cancel(); // Widget kapatıldığında timer'ı durduruyoruz
    _tabController?.dispose();
    super.dispose();
  }

  Future<void> _fetchChartData() async {
    setState(() {
      isLoading = true; // Yükleme başlıyor
      chartData = null; // Yeni veri için önceki veriyi temizliyoruz
    });
    try {
      Map<String, List<FlSpot>> data = await fetchCryptoChartData(selectedRange);
      setState(() {
        chartData = data;
        _calculatePriceStats();
      });
    } catch (e) {
      print("Hata: $e");
    } finally {
      setState(() {
        isLoading = false; // Yükleme tamamlandı
      });
    }
  }

  void _calculatePriceStats() {
    if (chartData != null && chartData![selectedRange]!.isNotEmpty) {
      final prices = chartData![selectedRange]!.map((spot) => spot.y).toList();
      lastPrice = prices.last;
      highPrice = prices.reduce((a, b) => a > b ? a : b);
      lowPrice = prices.reduce((a, b) => a < b ? a : b);
      change = prices.last - prices.first;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(' '),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          IconButton(
            icon: isLoading
                ? CircularProgressIndicator(color: Colors.white) // Yüklenirken dönen animasyon
                : Icon(Icons.refresh, color: Colors.white),
            onPressed: isLoading ? null : _fetchChartData, // Yükleme sırasında buton devre dışı
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'btcusdt',
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
            Text(
              lastPrice != null ? '\$${lastPrice!.toStringAsFixed(2)}' : 'Loading...',
              style: TextStyle(
                color: Colors.white,
                fontSize: 40,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              change != null ? '${change!.toStringAsFixed(2)} (${((change! / lastPrice!) * 100).toStringAsFixed(2)}%)' : '',
              style: TextStyle(
                color: change != null && change! >= 0 ? Colors.green : Colors.red,
                fontSize: 16,
              ),
            ),
            SizedBox(height: 16),
            TabBar(
              controller: _tabController,
              isScrollable: true,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.grey,
              indicatorColor: Colors.white,
              tabs: ranges.map((range) => Tab(text: range.toUpperCase())).toList(),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.4,
              child: chartData != null
                  ? Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: LineChart(
                  LineChartData(
                    gridData: FlGridData(show: false),
                    titlesData: FlTitlesData(show: false),
                    borderData: FlBorderData(show: false),
                    lineBarsData: [
                      LineChartBarData(
                        spots: chartData![selectedRange] ?? [],
                        isCurved: true,
                        colors: [Colors.greenAccent],
                        dotData: FlDotData(show: false),
                        belowBarData: BarAreaData(
                          show: true,
                          colors: [Colors.green.withOpacity(0.3)],
                        ),
                      ),
                    ],
                  ),
                ),
              )
                  : Center(child: CircularProgressIndicator()),
            ),
            SizedBox(height: 16),
            Text(
              'Price',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 8),
            _buildPriceDetailRow('Last:', lastPrice),
            _buildPriceDetailRow('High:', highPrice),
            _buildPriceDetailRow('Low:', lowPrice),
          ],
        ),
      ),
    );
  }

  Widget _buildPriceDetailRow(String label, double? value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(color: Colors.grey)),
        Text(
          value != null ? value.toStringAsFixed(2) : '...',
          style: TextStyle(color: Colors.white),
        ),
      ],
    );
  }

  Future<Map<String, List<FlSpot>>> fetchCryptoChartData(String range) async {
    String days = _convertRangeToDays(range);
    final response = await http.get(Uri.parse(
        'https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=$days'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      List<dynamic> prices = data['prices'];

      if (prices.isEmpty) {
        throw Exception('Seçilen zaman aralığı için veri bulunamadı.');
      }

      List<FlSpot> spots = [];
      for (var price in prices) {
        var timestamp = DateTime.fromMillisecondsSinceEpoch(price[0].toInt()).millisecondsSinceEpoch / 1000;
        var value = price[1].toDouble();
        spots.add(FlSpot(timestamp.toDouble(), value));
      }

      return {
        range: spots,
      };
    } else {
      throw Exception('Grafik verisi alınırken hata oluştu');
    }
  }

  String _convertRangeToDays(String range) {
    const ranges = {
      '10m': '0.0069',
      '30m': '0.0208',
      '1h': '0.0417',
      '4h': '0.167',
      '24h': '1',
      '7d': '7',
      '1m': '30',
    };
    return ranges[range] ?? '1';
  }
}
