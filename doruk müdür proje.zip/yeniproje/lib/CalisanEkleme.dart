import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'DetayliCiktiRaporu.dart';
import 'Logo.dart';

class CalisanEklemePage extends StatefulWidget {
  const CalisanEklemePage({Key? key}) : super(key: key);

  @override
  _CalisanEklemePageState createState() => _CalisanEklemePageState();
}

class _CalisanEklemePageState extends State<CalisanEklemePage> {
  // Form kontrolleri
  final TextEditingController nameController = TextEditingController();
  final TextEditingController tcController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  String selectedBirim = 'Birim Seçiniz';
  String selectedGorev = 'Görev Seçiniz';

  Future<void> _kaydetVeAPIyeGonder() async {
    if (nameController.text.isEmpty || emailController.text.isEmpty) {
      _showAlertDialog('Hata', 'Lütfen tüm alanları doldurun.');
      return;
    }

    final Map<String, String> requestBody = {
      "username": nameController.text,
      "email": emailController.text,
      "user_role": usernameController.text,
      "department": selectedBirim,
      "gender": "Erkek" // Örnek değer
    };

    final response = await http.post(
      Uri.parse('https://s3uploader.fly.dev/users'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(requestBody),
    );

    if (response.statusCode == 201) {
      _showSuccessDialog();
    } else {
      _showAlertDialog('Hata', 'Kayıt sırasında bir sorun oluştu.');
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Başarılı'),
          content: Text('Kişi başarıyla kaydedildi.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: Text('Tamam'),
            ),
          ],
        );
      },
    );
  }

  void _showAlertDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Tamam'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context); // Geri tuşuna basıldığında önceki sayfaya dön
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Spacer(),
            IconButton(
              icon: Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.calendar_today, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.notifications, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTextField('İsim Soyisim', controller: nameController),
              SizedBox(height: 16),
              _buildTextField('T.C. Kimlik Numarası', controller: tcController),
              SizedBox(height: 16),
              _buildTextField('Doğum Tarihi', controller: dobController, suffixIcon: Icons.calendar_today),
              SizedBox(height: 16),
              _buildTextField('Telefon', controller: phoneController),
              SizedBox(height: 16),
              _buildTextField('E-posta', controller: emailController),
              SizedBox(height: 16),
              _buildTextField('Departman', controller: usernameController),
              SizedBox(height: 16),
              _buildTextField('Şifre', controller: passwordController, obscureText: true),
              SizedBox(height: 16),
              _buildDropdownField('Birim Seçiniz', [
                'Resepsiyon',
                'Mutfak',
                'Temizlik',
                'Elektrik',
                'Komi',
                'Teknik',
                'Lorem Ipsum'
              ], (String? newValue) {
                setState(() {
                  selectedBirim = newValue!;
                });
              }),
              SizedBox(height: 16),
              _buildDropdownField('Görev Seçiniz', [
                'Görev 1',
                'Görev 2',
                'Görev 3'
              ], (String? newValue) {
                setState(() {
                  selectedGorev = newValue!;
                });
              }),
              SizedBox(height: 32),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 36.0),
                child: ElevatedButton(
                  onPressed: _kaydetVeAPIyeGonder,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1F74EC),
                    minimumSize: Size(361, 42),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21),
                    ),
                  ),
                  child: Text(
                    'Kaydet',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 60,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xFF4E1BD9),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(35),
            topRight: Radius.circular(35),
            bottomLeft: Radius.circular(35),
            bottomRight: Radius.circular(35),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
                padding: const EdgeInsets.only(left: 60.0),
                child: IconButton(
                  icon: Icon(Icons.home, size: 29, color: Colors.white),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  },
                )),
            Padding(
              padding: const EdgeInsets.only(right: 60.0),
              child: IconButton(
                icon: Icon(Icons.person, size: 29, color: Colors.white),
                onPressed: () {
                  // Profil sayfasına yönlendirme
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5,
          ),
        ),
        child: IconButton(
          icon: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => DetayliCiktiRaporu()),
            );
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildTextField(String label, {TextEditingController? controller, bool obscureText = false, IconData? suffixIcon}) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
        suffixIcon: suffixIcon != null ? Icon(suffixIcon) : null,
      ),
    );
  }

  Widget _buildDropdownField(String label, List<String> options, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
      ),
      items: options.map((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
      onChanged: onChanged,
    );
  }
}
