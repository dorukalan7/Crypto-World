import 'package:flutter/material.dart';

class IsAtamasiMusteri extends StatefulWidget {
  const IsAtamasiMusteri({Key? key}) : super(key: key);

  @override
  _IsAtamasiMusteriState createState() => _IsAtamasiMusteriState();
}

class _IsAtamasiMusteriState extends State<IsAtamasiMusteri> {
  String selectedBirim = 'Birim seçiniz';
  String selectedArizaTipi = 'Arıza tipi';
  String selectedKatOda = 'Kat/oda';
  Map<String, bool> importanceValues = {
    'Low': false,
    'Medium': false,
    'High': false,
    'CRITICAL': false,
  };

  void _showOptionsDialog(BuildContext context, String title, List<String> options, Function(String) onSelected) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: options.map((option) {
                return ListTile(
                  title: Text(option),
                  onTap: () {
                    onSelected(option);
                    Navigator.pop(context);
                  },
                );
              }).toList(),
            ),
          ),
        );
      },
    );
  }

  void _showConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.check,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Tebrikler',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 8),
                Text(
                  'İş atandı',
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1F74EC),
                  ),
                  child: Text(
                    'Tamam',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Spacer(),
            IconButton(
              icon: Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.calendar_today, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.notifications, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  _showOptionsDialog(context, 'Birim Seçiniz', ['Resepsiyon', 'Mutfak', 'Temizlik', 'Elektrik', 'Komi', 'Teknik', 'Lorem Ipsum'],
                          (selected) {
                        setState(() {
                          selectedBirim = selected;
                        });
                      });
                },
                child: _buildSelectableField(selectedBirim),
              ),
              SizedBox(height: 16),
              GestureDetector(
                onTap: () {
                  _showOptionsDialog(context, 'Arıza Tipi', ['Tip 1', 'Tip 2', 'Tip 3'],
                          (selected) {
                        setState(() {
                          selectedArizaTipi = selected;
                        });
                      });
                },
                child: _buildSelectableField(selectedArizaTipi),
              ),
              SizedBox(height: 16),
              GestureDetector(
                onTap: () {
                  _showOptionsDialog(context, 'Kat/oda', ['Kat 1', 'Kat 2', 'Kat 3'],
                          (selected) {
                        setState(() {
                          selectedKatOda = selected;
                        });
                      });
                },
                child: _buildSelectableField(selectedKatOda),
              ),
              SizedBox(height: 16),
              _buildFormField('ARIZA BELİRTİNİZ', maxLines: 4),
              SizedBox(height: 24),
              Text(
                'İş Önemi',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              Wrap(
                spacing: 8.0,
                runSpacing: 4.0,
                children: ['Low', 'Medium', 'High', 'CRITICAL'].map((label) {
                  return ChoiceChip(
                    label: Text(label),
                    selected: importanceValues[label]!,
                    onSelected: (bool selected) {
                      setState(() {
                        importanceValues[label] = selected;
                      });
                    },
                    selectedColor: Colors.blue,
                    backgroundColor: Colors.grey.shade200,
                    labelStyle: TextStyle(
                      color: importanceValues[label]! ? Colors.white : Colors.black,
                    ),
                  );
                }).toList(),
              ),
              SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: ElevatedButton(
                  onPressed: () {
                    _showConfirmationDialog(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1F74EC),
                    minimumSize: Size(double.infinity, 42),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21),
                    ),
                  ),
                  child: Text(
                    'Gönder',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Container(
          height: 60,
          decoration: BoxDecoration(
            color: Color(0xFF4E1BD9),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(35),
              topRight: Radius.circular(35),
            ),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Positioned(
                left: 20,
                child: IconButton(
                  icon: Icon(Icons.home, size: 29, color: Colors.white),
                  onPressed: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
              ),
              Positioned(
                right: 20,
                child: IconButton(
                  icon: Icon(Icons.person, size: 29, color: Colors.white),
                  onPressed: () {},
                ),
              ),
              Positioned(
                bottom: 0,
                child: GestureDetector(
                  onTap: () {},
                  child: Container(
                    width: 80,
                    height: 81,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Color(0xFF23272C),
                        width: 0.5,
                      ),
                    ),
                    child: Center(
                      child: Icon(
                        Icons.calendar_today,
                        size: 40,
                        color: Color(0xFF23272C),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSelectableField(String label) {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 16, color: Colors.black),
          ),
          Icon(Icons.arrow_drop_down, color: Colors.black),
        ],
      ),
    );
  }

  Widget _buildFormField(String label, {int maxLines = 1}) {
    return TextField(
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }
}
