import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  Future<String> fetchQuote(String emotion) async {
    final response = await http.get(Uri.parse('https://favqs.com/api/quotes/?filter=$emotion'));

    if (response.statusCode == 200) {
      // Başarılı bir şekilde yanıt alındı, verileri işleyin.
      // response.body içinde API'den gelen veriler bulunacaktır.
      print('API Response: ${response.body}');

      // Burada response.body'den alıntıları çıkarmalısınız ve bir alıntı olarak döndürmelisiniz.
      List<dynamic> quotes = jsonDecode(response.body)['quotes'];
      if (quotes.isNotEmpty) {
        return quotes[0]['body']; // Sadece ilk alıntıyı alıyoruz, siz isteğiniz doğrultusunda ayarlayabilirsiniz.
      } else {
        return 'No quotes available for $emotion.';
      }
    } else {
      // Yanıt alınamadı, hata durumunu işleyin.
      print('Failed to fetch quotes. Status Code: ${response.statusCode}');
      throw Exception('Failed to fetch quotes');
    }
  }
}
