import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'DetayliCiktiRaporu.dart';
import 'Logo.dart';
import 'acilIsler.dart';

class IsAtamasi extends StatefulWidget {
  const IsAtamasi({Key? key}) : super(key: key);

  @override
  _IsAtamasiState createState() => _IsAtamasiState();
}

class _IsAtamasiState extends State<IsAtamasi> {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();
  String? deviceToken;

  String selectedBirim = 'Birim seçiniz';
  String? selectedImportance = 'Low';
  Map<String, bool> checkboxValues = {
    'Tek Sefer': false,
    'Günlük': false,
    'Haftalık': false,
    'Aylık': false,
    'Yıllık': false,
  };

  @override
  void initState() {
    super.initState();
    _initializeFirebaseMessaging();
    _getDeviceToken();
  }

  void _getDeviceToken() async {
    String? token = await FirebaseMessaging.instance.getToken();
    print("Cihaz Tokeni: $token");
    // Bu tokeni sunucu tarafında kullanmak için saklayın.
  }

  void _initializeFirebaseMessaging() {
    FirebaseMessaging.instance.requestPermission();
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Bildirim alındı: ${message.notification?.title}');
    });
  }

  void _initializeLocalNotifications() {
    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');
    final InitializationSettings initializationSettings =
    InitializationSettings(android: initializationSettingsAndroid);
    flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  void _showOptionsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildOptionItem(context, 'Resepsiyon'),
                _buildOptionItem(context, 'Mutfak'),
                _buildOptionItem(context, 'Temizlik'),
                _buildOptionItem(context, 'Elektrik'),
                _buildOptionItem(context, 'Komi'),
                _buildOptionItem(context, 'Teknik'),
                _buildOptionItem(context, 'Lorem Ipsum'),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showConfirmationDialog(BuildContext context) {
    if (selectedImportance == 'CRITICAL') {
      // Bildirim gönderme fonksiyonunu çağırın
      _sendNotificationRequestToServer();
    }
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5), // Arka planı karartır
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 60,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.check,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Tebrikler',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 8),
                Text(
                  'İş atandı',
                  style: TextStyle(
                    fontSize: 12,
                    fontFamily: 'LibreFranklin-Medium',
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Onay modalını kapatır
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1F74EC),
                  ),
                  child: Text(
                    'Tamam',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _sendFirebaseNotification() async {
    // Firebase Messaging ile bildirim gönderme işlemi burada gerçekleştirilir.
    print('acil iş bildirim gönderildi.');
  }

  Future<void> _sendNotificationRequestToServer() async {
    final response = await http.post(
      Uri.parse('https://your-backend-url.com/send-notification'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'title': 'Acil İş Uyarısı',
        'body': 'Bir kritik iş atanmıştır!',
        'token': deviceToken, // Cihaz tokenini burada kullanın
      }),
    );

    if (response.statusCode == 200) {
      print('Bildirim talebi sunucuya gönderildi');
    } else {
      print('Bildirim talebi başarısız oldu: ${response.statusCode}');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Spacer(),
            IconButton(
              icon: Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.calendar_today, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.notifications, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  _showOptionsDialog(context);
                },
                child: Container(
                  padding: EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        selectedBirim,
                        style: TextStyle(fontSize: 16, color: Colors.black),
                      ),
                      Icon(Icons.arrow_drop_down, color: Colors.black),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              _buildFormField('Personel seçiniz', controller: assigneeController),
              SizedBox(height: 16),
              _buildFormField('Görev belirtiniz', controller: taskController),
              SizedBox(height: 16),
              Text(
                'Tanımlama süresi',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: _buildDateField('Başlangıç tarihi', startDateController)),
                  SizedBox(width: 16),
                  Expanded(child: _buildDateField('Bitiş tarihi', endDateController)),
                ],
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: _buildDateField('Başlangıç saati', startTimeController)),
                  SizedBox(width: 16),
                  Expanded(child: _buildDateField('Bitiş saati', endTimeController)),
                ],
              ),
              SizedBox(height: 16),
              _buildFormField('Detay yazınız', maxLines: 4),
              SizedBox(height: 24),
              Text(
                'Zaman sıklığı',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              Wrap(
                spacing: 8.0,
                runSpacing: 4.0,
                children: ['Tek Sefer', 'Günlük', 'Haftalık', 'Aylık', 'Yıllık']
                    .map((label) => _buildCheckbox(label))
                    .toList(),
              ),
              SizedBox(height: 24),
              Text(
                'İş önemi',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              Wrap(
                spacing: 8.0,
                runSpacing: 4.0,
                children: ['Low', 'Medium', 'High', 'CRITICAL']
                    .map((label) => _buildRadio(label))
                    .toList(),
              ),
              SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 36.0),
                child: ElevatedButton(
                  onPressed: () async {
                    final taskData = {
                      "title": taskController.text,
                      "department": selectedBirim,
                      "assignee": assigneeController.text,
                      "status": "inprogress",
                      "priority": selectedImportance?.toLowerCase(),
                      "frequency": checkboxValues.keys.where((key) => checkboxValues[key]!).join(','),
                      "dueDate": endDateController.text,
                    };

                    try {
                      final response = await http.post(
                        Uri.parse('https://s3uploader.fly.dev/tasks'),
                        headers: {'Content-Type': 'application/json'},
                        body: json.encode(taskData),
                      );

                      if (response.statusCode == 200) {
                        final responseData = json.decode(response.body);
                        print('Görev başarıyla oluşturuldu: ${responseData['task_id']}');

                        if (selectedImportance == 'CRITICAL') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => AcilIsler()),
                          );
                        } else {
                          _showConfirmationDialog(context);
                        }
                      } else {
                        print('Görev oluşturulamadı: ${response.statusCode}');
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Görev oluşturulurken hata oluştu.')),
                        );
                      }
                    } catch (error) {
                      print('Bir hata oluştu: $error');
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Bir hata oluştu. Lütfen tekrar deneyin.')),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1F74EC),
                    minimumSize: Size(double.infinity, 42),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21),
                    ),
                  ),
                  child: Text(
                    'Oluştur',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),
              // Yeni eklenen bildirim gönderme butonu
              ElevatedButton(
                onPressed: () {
                  _sendNotificationRequestToServer(); // Bildirim gönderimini tetikler
                },
                child: Text('Bildirim Gönder'),
              ),
            ],
          ),
        ),
      ),

      bottomNavigationBar: Container(
        height: 60,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xFF4E1BD9),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(35),
            topRight: Radius.circular(35),
            bottomLeft: Radius.circular(35),
            bottomRight: Radius.circular(35),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
                padding: const EdgeInsets.only(left: 60.0),
                child: IconButton(
                  icon: Icon(Icons.home, size: 29, color: Colors.white),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  },
                )),
            Padding(
              padding: const EdgeInsets.only(right: 60.0),
              child: IconButton(
                icon: Icon(Icons.person, size: 29, color: Colors.white),
                onPressed: () {
                  // Profil sayfasına yönlendirme
                },
              ),
            ),],

        ),
      ),
      floatingActionButton: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5, // Kenar boşluğu kalınlığı
          ),
        ),
        child: IconButton(
          icon: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => DetayliCiktiRaporu()),
            );
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildOptionItem(BuildContext context, String option) {
    return ListTile(
      title: Text(option),
      onTap: () {
        setState(() {
          selectedBirim = option;
        });
        Navigator.pop(context);
      },
    );
  }
  TextEditingController assigneeController = TextEditingController();
  TextEditingController taskController = TextEditingController();
  TextEditingController startDateController = TextEditingController();
  TextEditingController endDateController = TextEditingController();
  TextEditingController startTimeController = TextEditingController();
  TextEditingController endTimeController = TextEditingController();

  Widget _buildFormField(String label, {int maxLines = 1, TextEditingController? controller}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }


  Widget _buildDateField(String label, TextEditingController controller) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              labelText: label,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
            readOnly: true, // Kullanıcı metin alanına doğrudan yazamaz
          ),
        ),
        IconButton(
          icon: Icon(Icons.calendar_today, color: Colors.black),
          onPressed: () {
            _selectDate(context, controller); // Tarih seçici fonksiyonunu çağırır
          },
        ),
      ],
    );
  }

  Future<void> _selectDate(BuildContext context, TextEditingController controller) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );

    if (pickedDate != null) {
      setState(() {
        controller.text = "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
      });
    }
  }


  Widget _buildTimeField(String label, TextEditingController controller) {
    return GestureDetector(
      onTap: () => _selectTime(context, controller),
      child: AbsorbPointer(
        child: TextField(
          controller: controller,
          decoration: InputDecoration(
            labelText: label,
            suffixIcon: Icon(Icons.access_time), // Saat ikonu
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
        ),
      ),
    );
  }


  Future<void> _selectTime(BuildContext context, TextEditingController controller) async {
    TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (pickedTime != null) {
      setState(() {
        controller.text = pickedTime.format(context); // Seçilen saati formatlar ve controller'a ekler.
      });
    }
  }


  Widget _buildCheckbox(String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Checkbox(
          value: checkboxValues[label],
          onChanged: (bool? value) {
            setState(() {
              checkboxValues[label] = value ?? false;
            });
          },
        ),
        Text(label),
      ],
    );
  }

  Widget _buildRadio(String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Radio<String>(
          value: label,
          groupValue: selectedImportance,
          onChanged: (String? value) {
            setState(() {
              selectedImportance = value;
            });
          },
        ),
        Text(label),
      ],
    );
  }
}
