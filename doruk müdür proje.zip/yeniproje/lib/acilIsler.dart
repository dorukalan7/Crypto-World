import 'package:flutter/material.dart';
import 'DetayCiktiRaporu.dart';
import 'DetaySayfasi.dart';
import 'Logo.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AcilIsler extends StatefulWidget {
  const AcilIsler({Key? key}) : super(key: key);

  @override
  _AcilIslerState createState() => _AcilIslerState();
}

class _AcilIslerState extends State<AcilIsler> {
  bool isAcilIcerikSelected = true;
  List<Map<String, dynamic>> criticalTasks = [];

  @override
  void initState() {
    super.initState();
    fetchCriticalTasks(); // Sayfa yüklendiğinde CRITICAL görevleri çek
  }

  Future<void> fetchCriticalTasks() async {
    try {
      final response = await http.get(Uri.parse('https://s3uploader.fly.dev/tasks?priority=critical'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          criticalTasks = List<Map<String, dynamic>>.from(data['tasks']);
        });
      } else {
        print('Failed to load critical tasks: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching critical tasks: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.search, color: Colors.black),
                  onPressed: () {},
                ),
                IconButton(
                  icon: Icon(Icons.notifications, color: Colors.black),
                  onPressed: () {},
                ),
                CircleAvatar(
                  backgroundColor: Colors.grey,
                  child: Icon(Icons.person, color: Colors.white),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Tabs for "Acil İçerik" and "Üzerime Atananlar"
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildTabButton('Acil İçerik (${criticalTasks.length})', true),
                _buildTabButton('Üzerime Atananlar', false),
              ],
            ),
            SizedBox(height: 16),
            // Display based on tab selection
            _buildStatusContainer(criticalTasks.length),
            SizedBox(height: 16),
            Expanded(
              child: isAcilIcerikSelected ? _buildAcilIsContent() : _buildUzerimeAtananlarContent(),
            ),
            SizedBox(height: 8),
            _buildPagination(),
            SizedBox(height: 16),
          ],
        ),
      ),
      bottomNavigationBar: buildBottomNavigationBar(context),
      floatingActionButton: _buildFloatingCenterButton(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildTabButton(String title, bool isAcilIcerik) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isAcilIcerikSelected = isAcilIcerik;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isAcilIcerik == isAcilIcerikSelected ? Colors.blue : Colors.grey.shade200,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          title,
          style: TextStyle(
            color: isAcilIcerik == isAcilIcerikSelected ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildStatusContainer(int taskCount) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Color(0xFFDDFCE0), // Light green background
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'acil iş',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            taskCount.toString(), // CRITICAL iş sayısını göster
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildAcilIsContent() {
    return criticalTasks.isEmpty
        ? Center(child: Text('CRITICAL iş bulunamadı.'))
        : ListView.builder(
      itemCount: criticalTasks.length,
      itemBuilder: (context, index) {
        final task = criticalTasks[index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DetaySayfasi(
                  taskDetails: task,
                  odaBilgisi: {}, // Oda bilgisi dolu olmalı veya uygun veri ile doldurulmalı.
                  taskId: task['id'], // Eğer `id` varsa bu şekilde kullanın.
                ),
              ),
            );

          },
          child: Card(
            margin: EdgeInsets.only(bottom: 16.0),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task['title'] ?? 'Görev Başlığı Yok',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text('Oluşturulma Tarihi: ${task['created_at'] ?? 'Bilinmiyor'}'),
                  Text('Başlama Zamanı: ${task['start_time'] ?? 'Bilinmiyor'}'),
                  Text('Tamamlanma Zamanı: ${task['complete_time'] ?? 'Bilinmiyor'}'),
                  SizedBox(height: 8),
                  Text(
                    'Öncelik: ${task['priority']?.toUpperCase() ?? 'Bilinmiyor'}',
                    style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }


  Widget _buildUzerimeAtananlarContent() {
    return ListView(
      children: [
        _buildTaskCard(
          '409 Numaralı Oda Temizliği',
          '12/01/2024 - 14.15',
          '12/01/2024 - 14.30',
          '',
        ),
        _buildTaskCard(
          '408 Numaralı Oda Temizliği',
          '12/01/2024 - 13.30',
          '12/01/2024 - 14.00',
          '',
        ),
      ],
    );
  }

  Widget _buildTaskCard(String title, String sendTime, String deliveryTime, String duration) {
    return Card(
      margin: EdgeInsets.only(bottom: 16.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            SizedBox(height: 8),
            Text('gönderilme zamanı: $sendTime'),
            Text('teslim zamanı: $deliveryTime'),
            if (duration.isNotEmpty)
              Text(
                'sÜRE: $duration',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPagination() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('Sayfa 1-50 arası'),
        IconButton(icon: Icon(Icons.arrow_left), onPressed: () {}),
        IconButton(icon: Icon(Icons.arrow_right), onPressed: () {}),
      ],
    );
  }

  Widget buildBottomNavigationBar(BuildContext context) {
    return Container(
      height: 60,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Color(0xFF4E1BD9),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(35),
          topRight: Radius.circular(35),
          bottomLeft: Radius.circular(35),
          bottomRight: Radius.circular(35),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 60.0),
            child: IconButton(
              icon: Icon(Icons.home, size: 29, color: Colors.white),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 60.0),
            child: IconButton(
              icon: Icon(Icons.person, size: 29, color: Colors.white),
              onPressed: () {
                // Profil sayfasına yönlendirme
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingCenterButton(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: Color(0xFF23272C),
            width: 0.5,
          ),
        ),
        child: Center(
          child: Icon(
            Icons.article,
            size: 40,
            color: Color(0xFF23272C),
          ),
        ),
      ),
    );
  }
}
