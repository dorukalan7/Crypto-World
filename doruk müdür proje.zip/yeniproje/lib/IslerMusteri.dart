import 'package:flutter/material.dart';

import 'IsAtamasi.dart';
import 'IsAtamasiMusteri.dart';

class IslerMusteri extends StatefulWidget {
  const IslerMusteri({Key? key}) : super(key: key);

  @override
  _IslerMusteriState createState() => _IslerMusteriState();
}

class _IslerMusteriState extends State<IslerMusteri> {
  int selectedIndex = 0; // Seçili olan sekmeyi belirtir

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Logo', style: TextStyle(color: Colors.black)),
            Spacer(),
            IconButton(
              icon: Icon(Icons.search, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.calendar_today, color: Colors.black),
              onPressed: () {},
            ),
            IconButton(
              icon: Icon(Icons.notifications, color: Colors.black),
              onPressed: () {},
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween, // Sekmelerin aralığını ayarlar
              children: [
                _buildTabButton('Atanan', 0),
                _buildTabButton('Tamamlanan', 1),
                _buildTabButton('Tamamlanmadı', 2),
              ],
            ),
            SizedBox(height: 16),
            _buildStatusContainer(),
            SizedBox(height: 16),
            Expanded(
              child: _buildTabContent(),
            ),
            if (selectedIndex == 0)
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => IsAtamasiMusteri()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1F74EC), // Arka plan rengi
                    minimumSize: Size(double.infinity, 42), // Genişlik ve yükseklik
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(21), // Border radius
                    ),
                  ),
                  child: Text(
                    '+ Ekle',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),

          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Container(
          height: 60,
          decoration: BoxDecoration(
            color: Color(0xFF4E1BD9),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(35),
              topRight: Radius.circular(35),
            ),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Positioned(
                left: 20,
                child: IconButton(
                  icon: Icon(Icons.home, size: 29, color: Colors.white),
                  onPressed: () {
                    Navigator.pushNamed(context, '/home');
                  },
                ),
              ),
              Positioned(
                right: 20,
                child: IconButton(
                  icon: Icon(Icons.person, size: 29, color: Colors.white),
                  onPressed: () {},
                ),
              ),
              Positioned(
                bottom: 0,
                child: GestureDetector(
                  onTap: () {
                    // Başka bir işlem veya sayfa yönlendirmesi
                  },
                  child: Container(
                    width: 80,
                    height: 81,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Color(0xFF23272C),
                        width: 0.5,
                      ),
                    ),
                    child: Center(
                      child: Icon(
                        Icons.newspaper,
                        size: 40,
                        color: Color(0xFF23272C),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabButton(String title, int index) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedIndex = index;
          });
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 8.0),
          decoration: BoxDecoration(
            color: selectedIndex == index ? Colors.blue : Colors.grey.shade300,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Center(
            child: Text(
              title,
              style: TextStyle(
                color: selectedIndex == index ? Colors.white : Colors.black,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusContainer() {
    Color backgroundColor;
    String countText;

    switch (selectedIndex) {
      case 0:
        backgroundColor = Color(0xFFDDFCE0); // Atanan
        countText = '32'; // Örnek sayı
        break;
      case 1:
        backgroundColor = Color(0xFFF3EEFE); // Tamamlanan
        countText = '0';
        break;
      case 2:
        backgroundColor = Color(0xFFFEF0DB); // Tamamlanmadı
        countText = '0';
        break;
      default:
        backgroundColor = Colors.white;
        countText = '';
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: backgroundColor, // Arka plan rengi
        borderRadius: BorderRadius.circular(20), // Border radius
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            selectedIndex == 0
                ? 'Atanan İş'
                : selectedIndex == 1
                ? 'Tamamlanan İş'
                : 'Tamamlanmayan İş',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          Text(
            countText,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabContent() {
    switch (selectedIndex) {
      case 0:
        return _buildAtananContent();
      case 1:
        return _buildTamamlananContent();
      case 2:
        return _buildTamamlanmadiContent();
      default:
        return Container();
    }
  }

  Widget _buildAtananContent() {
    return ListView(
      children: [
        _buildTaskCard(
          'Samet Terzioğlu',
          'Kat Temizliği',
          '3 Kat 2 Blok Kat Temizliği',
          'Bekleniyor',
        ),
        _buildTaskCard(
          'Uğur Işık',
          'Oda Hizmetlisi',
          '3 Kat 408 Nolu Oda Temizliği',
          'Bekleniyor',
        ),
      ],
    );
  }

  Widget _buildTamamlananContent() {
    return Center(child: Text('Tamamlanan İşler Gösteriliyor'));
  }

  Widget _buildTamamlanmadiContent() {
    return Center(child: Text('Tamamlanmadı İşler Gösteriliyor'));
  }

  Widget _buildTaskCard(String name, String role, String task, String status) {
    return Card(
      margin: EdgeInsets.only(bottom: 16.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: Colors.grey.shade300,
                ),
                SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Text(role, style: TextStyle(color: Colors.grey)),
                  ],
                ),
                Spacer(),
                Icon(Icons.more_vert, color: Colors.black),
              ],
            ),
            SizedBox(height: 16),
            Text('Görev: $task'),
            SizedBox(height: 8),
            Text('Durum: $status', style: TextStyle(color: Colors.red)),
          ],
        ),
      ),
    );
  }
}
