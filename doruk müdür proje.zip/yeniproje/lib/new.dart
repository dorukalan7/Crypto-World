import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper.internal();
  factory DatabaseHelper() => _instance;

  DatabaseHelper.internal();

  static Database? _db;

  Future<Database?> get db async {
    if (_db != null) return _db;
    _db = await initDatabase();
    return _db;
  }

  Future<Database> initDatabase() async {
    String databasePath = await getDatabasesPath();
    String path = join(databasePath, 'my_database.db');

    return await openDatabase(
      path,
      version: 1, // Veritabanı sürümü
      onCreate: _onCreate,
    );
  }

  void _onCreate(Database db, int version) async {
    // Veritabanı tablolarını burada oluşturun
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT
      )
    ''');
  }

// Diğer veritabanı işlemleri için metodları ekleyin (veri ekleme, güncelleme, sorgulama, vb.).
}