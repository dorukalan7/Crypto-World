import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'CalisanEkleme.dart';
import 'DetayliCiktiRaporu.dart';
import 'Logo.dart'; // HomePage'i yönlendirmek için import edin

void main() {
  runApp(const CalisanlarPage());
}

class CalisanlarPage extends StatefulWidget {
  const CalisanlarPage({Key? key}) : super(key: key);

  @override
  _CalisanlarPageState createState() => _CalisanlarPageState();
}

class _CalisanlarPageState extends State<CalisanlarPage> {
  int currentPage = 1;
  int itemsPerPage = 10;
  List<Map<String, dynamic>> allEmployees = [];

  @override
  void initState() {
    super.initState();
    fetchEmployees();
  }

  Future<void> fetchEmployees() async {
    final response = await http.get(Uri.parse('https://s3uploader.fly.dev/users'));

    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      setState(() {
        allEmployees.clear();
        for (var item in data) {
          allEmployees.add({
            'username': item['username'] ?? 'Bilinmeyen',
            'user_role': item['user_role'] ?? 'Pozisyon Yok',
            'email': item['email'] ?? 'E-posta Yok',
            'department': item['department'] ?? 'Departman Yok',
          });
        }
      });
    } else {
      throw Exception('Çalışan verileri yüklenemedi');
    }
  }

  List<Map<String, dynamic>> getCurrentPageEmployees() {
    int startIndex = (currentPage - 1) * itemsPerPage;
    int endIndex = startIndex + itemsPerPage;
    return allEmployees.sublist(
      startIndex,
      endIndex > allEmployees.length ? allEmployees.length : endIndex,
    );
  }

  void _nextPage() {
    if ((currentPage * itemsPerPage) < allEmployees.length) {
      setState(() {
        currentPage++;
      });
    }
  }

  void _previousPage() {
    if (currentPage > 1) {
      setState(() {
        currentPage--;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Logo', style: TextStyle(color: Colors.black)),
              Spacer(),
              IconButton(
                icon: Icon(Icons.search, color: Colors.black),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.calendar_today, color: Colors.black),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.notifications, color: Colors.black),
                onPressed: () {},
              ),
            ],
          ),
        ),
        body: allEmployees.isEmpty
            ? Center(child: CircularProgressIndicator())
            : ListView(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          children: [
            Container(
              height: 60.0,
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Color(0xFFDDFCE0), // Arka plan rengi burada ayarlandı
                borderRadius: BorderRadius.circular(20), ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Toplam Çalışan',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black,
                        fontFamily: 'LibreFranklin',
                        fontWeight: FontWeight.w600,
                      )),
                  Text('${allEmployees.length}',
                      style: TextStyle(fontSize: 23, color: Colors.black)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () {},
                  icon: Icon(Icons.filter_list, color: Colors.black),
                  label: Text('Filtrele', style: TextStyle(color: Colors.black)),
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.grey.shade200,
                    padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                  ),
                ),
              ),
            ),
            // Çalışan kartları
            ...getCurrentPageEmployees().map((employee) {
              return _buildEmployeeCard(
                employee['username'] ?? 'Bilinmeyen',
                employee['user_role'] ?? 'Pozisyon Yok',
                '01/01/2024', // API'den tarih bilgisi çekilirse burayı değiştirin.
                employee['email'] ?? 'E-posta Yok',
                employee['department'] ?? 'Departman Yok',
              );
            }).toList(),

            // Sayfa 1 - 50 kısmı ve sayfa değiştirme okları
            _buildPagination(),

            // + Ekle butonu
            Padding(
              padding: const EdgeInsets.only(bottom: 40.0),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const CalisanEklemePage()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF1F74EC),
                  minimumSize: Size(361, 42),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(21),
                  ),
                ),
                child: Text(
                  '+ Ekle',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Container(
          height: 60,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Color(0xFF4E1BD9),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(35),
              topRight: Radius.circular(35),
              bottomLeft: Radius.circular(35),
              bottomRight: Radius.circular(35),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 60.0),
                child: IconButton(
                  icon: Icon(Icons.home, size: 29, color: Colors.white),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HomePage()),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 60.0),
                child: IconButton(
                  icon: Icon(Icons.person, size: 29, color: Colors.white),
                  onPressed: () {
                    // Profil sayfasına yönlendirme
                  },
                ),
              ),
            ],
          ),
        ),
        floatingActionButton: Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(
              color: Color(0xFF23272C),
              width: 0.5,
            ),
          ),
          child: IconButton(
            icon: Icon(
              Icons.article,
              size: 40,
              color: Color(0xFF23272C),
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DetayliCiktiRaporu()),
              );
            },
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }

  Widget _buildEmployeeCard(String name, String position, String date, String email, String department) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: Colors.grey.shade800,
                  radius: 20,
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      Text(position, style: TextStyle(color: Colors.purple)),
                    ],
                  ),
                ),
                PopupMenuButton<int>(
                  icon: Icon(Icons.more_horiz),
                  onSelected: (value) {
                    if (value == 0) {
                      // Düzenle işlemi
                    } else if (value == 1) {
                      // Silme işlemi
                    }
                  },
                  itemBuilder: (context) => [
                    PopupMenuItem<int>(
                      value: 0,
                      child: Row(
                        children: [
                          Icon(Icons.edit, color: Colors.black),
                          SizedBox(width: 8),
                          Text('Düzenle'),
                        ],
                      ),
                    ),
                    PopupMenuItem<int>(
                      value: 1,
                      child: Row(
                        children: [
                          Icon(Icons.delete, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Sil'),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 8),
            Text('İşe Başlama Tarihi: $date'),
            Text('E-POSTA: $email'),
            Text('DEPARTMAN: $department'),
          ],
        ),
      ),
    );
  }

  Widget _buildPagination() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          icon: Icon(Icons.arrow_left),
          onPressed: _previousPage,
        ),
        Text('Sayfa $currentPage - ${((allEmployees.length / itemsPerPage).ceil())} arası'),
        IconButton(
          icon: Icon(Icons.arrow_right),
          onPressed: _nextPage,
        ),
      ],
    );
  }
}
